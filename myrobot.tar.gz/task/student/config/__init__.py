"""Student task registration for multi-teacher distillation."""

from mjlab.tasks.registry import register_mjlab_task

from .env_cfg import (
    my_go2_flat_env_cfg,
    my_go2_low_clearance_bar_env_cfg,
    my_go2_platform_env_cfg,
    my_go2_plum_env_cfg,
    my_go2_stair_down_env_cfg,
    my_go2_stair_env_cfg,
    my_go2_stair_up_env_cfg,
    my_go2_stones_2rows_env_cfg,
    my_go2_tire_env_cfg,
)
from .mutitask_env_cfg import (
    my_go2_flat_platform_stair_down_env_cfg,
    my_go2_flat_platform_stair_down_plum_env_cfg,
    my_go2_flat_stair_down_env_cfg,
    my_go2_flat_stair_up_env_cfg,
    my_go2_half_competition_map_env_cfg,
)
from .multi_teacher import MultiTeacherDistillationRunner
from .rl_cfg import my_go2_multi_teacher_distill_cfg
from .teachers import (
    TEACHER_CHECKPOINTS,
    TEACHER_CHECKPOINTS_FLAT_STAIR_UP,
)

_TERRAINS = {
    "Flat": my_go2_flat_env_cfg,
    "Stair": my_go2_stair_env_cfg,
    "StairUp": my_go2_stair_up_env_cfg,
    "StairDown": my_go2_stair_down_env_cfg,
    "Platform": my_go2_platform_env_cfg,
    "PlumBlossom": my_go2_plum_env_cfg,
    "Stones2Rows": my_go2_stones_2rows_env_cfg,
    "TireArray": my_go2_tire_env_cfg,
    "LowClearanceBar": my_go2_low_clearance_bar_env_cfg,
}

for _name, _env_cfg in _TERRAINS.items():
    register_mjlab_task(
        task_id=f"Mjlab-Tracking-{_name}-Student-Unitree-Go2",
        env_cfg=_env_cfg(),
        play_env_cfg=_env_cfg(play=True),
        rl_cfg=my_go2_multi_teacher_distill_cfg(
            terrain_key=_name,
            teachers=TEACHER_CHECKPOINTS,
        ),
        runner_cls=MultiTeacherDistillationRunner,
    )

# Mixed flat + stair_up task: one student, two teachers, per-env routing.
register_mjlab_task(
    task_id="Mjlab-Tracking-FlatStairUp-Student-Unitree-Go2",
    env_cfg=my_go2_flat_stair_up_env_cfg(),
    play_env_cfg=my_go2_flat_stair_up_env_cfg(play=True),
    rl_cfg=my_go2_multi_teacher_distill_cfg(
        terrain_key="FlatStairUp",
        teachers=TEACHER_CHECKPOINTS_FLAT_STAIR_UP,
        multi_teacher=True,
    ),
    runner_cls=MultiTeacherDistillationRunner,
)

# Mixed flat + stair_down task: one student distilling from the generalist
# mixed teacher (privileged terrain_type input).  The student actor has no
# terrain_type; it must infer flat vs stair_down from height_scan/height_error.
# Deterministic student rollouts (mean action) avoid the stock Distillation
# std=1.0 action noise, which otherwise causes early falls and very short
# episodes.  To go back to per-terrain specialist teachers, set
# multi_teacher=True and pass TEACHER_CHECKPOINTS_FLAT_STAIR_DOWN instead.
register_mjlab_task(
    task_id="Mjlab-Tracking-FlatStairDown-Student-Unitree-Go2",
    env_cfg=my_go2_flat_stair_down_env_cfg(),
    play_env_cfg=my_go2_flat_stair_down_env_cfg(play=True),
    rl_cfg=my_go2_multi_teacher_distill_cfg(
        terrain_key="FlatStairDown",
        teachers=TEACHER_CHECKPOINTS,
        multi_teacher=False,
        gradient_length=24,
        deterministic_student=True,
    ),
    runner_cls=MultiTeacherDistillationRunner,
)

# Mixed flat + platform + stair_down task: one unlabeled student distilling
# from the generalist mixed teacher.  Actor has no terrain_type; the critic
# keeps the privileged one-hot.  Fill TEACHER_CHECKPOINTS["FlatPlatformStairDown"]
# after training the teacher.
register_mjlab_task(
    task_id="Mjlab-Tracking-FlatPlatformStairDown-Student-Unitree-Go2",
    env_cfg=my_go2_flat_platform_stair_down_env_cfg(),
    play_env_cfg=my_go2_flat_platform_stair_down_env_cfg(play=True),
    rl_cfg=my_go2_multi_teacher_distill_cfg(
        terrain_key="FlatPlatformStairDown",
        teachers=TEACHER_CHECKPOINTS,
        multi_teacher=False,
        gradient_length=24,
        deterministic_student=True,
    ),
    runner_cls=MultiTeacherDistillationRunner,
)

# Mixed flat + stair_down + platform + plum task: one unlabeled student
# distilling from the generalist teacher.  Fill
# TEACHER_CHECKPOINTS["FlatPlatformStairDownPlum"] after training the teacher.
register_mjlab_task(
    task_id="Mjlab-Tracking-FlatPlatformStairDownPlum-Student-Unitree-Go2",
    env_cfg=my_go2_flat_platform_stair_down_plum_env_cfg(),
    play_env_cfg=my_go2_flat_platform_stair_down_plum_env_cfg(play=True),
    rl_cfg=my_go2_multi_teacher_distill_cfg(
        terrain_key="FlatPlatformStairDownPlum",
        teachers=TEACHER_CHECKPOINTS,
        multi_teacher=False,
        gradient_length=24,
        deterministic_student=True,
    ),
    runner_cls=MultiTeacherDistillationRunner,
)

# Composite half-competition map.  Single generalist teacher checkpoint.
register_mjlab_task(
    task_id="Mjlab-Tracking-HalfCompetitionMap-Student-Unitree-Go2",
    env_cfg=my_go2_half_competition_map_env_cfg(),
    play_env_cfg=my_go2_half_competition_map_env_cfg(play=True),
    rl_cfg=my_go2_multi_teacher_distill_cfg(
        terrain_key="HalfCompetitionMap",
        teachers=TEACHER_CHECKPOINTS,
        multi_teacher=False,
        gradient_length=24,
        deterministic_student=True,
    ),
    runner_cls=MultiTeacherDistillationRunner,
)

__all__ = ["_TERRAINS"]
